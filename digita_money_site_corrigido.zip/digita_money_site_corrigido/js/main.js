// Digita Money - Main JavaScript

// Esperar pelo carregamento completo do DOM
document.addEventListener('DOMContentLoaded', function() {
    // Preloader
    setTimeout(function() {
        const preloader = document.querySelector('.preloader');
        preloader.classList.add('hide');
    }, 1000);

    // Header fixo ao rolar
    const header = document.querySelector('.site-header');
    window.addEventListener('scroll', function() {
        if (window.scrollY > 50) {
            header.classList.add('scrolled');
        } else {
            header.classList.remove('scrolled');
        }
    });

    // Menu mobile
    const menuToggle = document.querySelector('.mobile-menu-toggle');
    const mainNav = document.querySelector('.main-nav');
    if (menuToggle) {
        menuToggle.addEventListener('click', function() {
            mainNav.classList.toggle('show');
        });
    }

    // Carrossel de vídeos
    const videoSlides = document.querySelectorAll('.video-slide');
    const carouselDots = document.querySelectorAll('.carousel-dot');
    let currentVideoSlide = 0;
    let videoInterval;

    function startVideoCarousel() {
        videoInterval = setInterval(nextVideoSlide, 8000);
    }

    function stopVideoCarousel() {
        clearInterval(videoInterval);
    }

    function showVideoSlide(index) {
        videoSlides.forEach(slide => slide.classList.remove('active'));
        carouselDots.forEach(dot => dot.classList.remove('active'));
        
        videoSlides[index].classList.add('active');
        carouselDots[index].classList.add('active');
        
        currentVideoSlide = index;
    }

    function nextVideoSlide() {
        let nextSlide = currentVideoSlide + 1;
        if (nextSlide >= videoSlides.length) {
            nextSlide = 0;
        }
        showVideoSlide(nextSlide);
    }

    if (carouselDots.length > 0) {
        carouselDots.forEach((dot, index) => {
            dot.addEventListener('click', function() {
                stopVideoCarousel();
                showVideoSlide(index);
                startVideoCarousel();
            });
        });
        
        startVideoCarousel();
    }

    // Carrossel de depoimentos
    const testimonialSlides = document.querySelectorAll('.testimonial-slide');
    const testimonialDots = document.querySelectorAll('.testimonial-dot');
    let currentTestimonialSlide = 0;
    let testimonialInterval;

    function startTestimonialCarousel() {
        testimonialInterval = setInterval(nextTestimonialSlide, 5000);
    }

    function stopTestimonialCarousel() {
        clearInterval(testimonialInterval);
    }

    function showTestimonialSlide(index) {
        testimonialSlides.forEach(slide => slide.classList.remove('active'));
        testimonialDots.forEach(dot => dot.classList.remove('active'));
        
        testimonialSlides[index].classList.add('active');
        testimonialDots[index].classList.add('active');
        
        currentTestimonialSlide = index;
    }

    function nextTestimonialSlide() {
        let nextSlide = currentTestimonialSlide + 1;
        if (nextSlide >= testimonialSlides.length) {
            nextSlide = 0;
        }
        showTestimonialSlide(nextSlide);
    }

    if (testimonialDots.length > 0) {
        testimonialDots.forEach((dot, index) => {
            dot.addEventListener('click', function() {
                stopTestimonialCarousel();
                showTestimonialSlide(index);
                startTestimonialCarousel();
            });
        });
        
        startTestimonialCarousel();
    }

    // Contador de estatísticas
    const statNumbers = document.querySelectorAll('.stat-number');
    let counted = false;

    function startCounting() {
        if (counted) return;
        
        statNumbers.forEach(stat => {
            const target = parseInt(stat.getAttribute('data-count'));
            const duration = 2000; // 2 segundos
            const increment = target / (duration / 16);
            let current = 0;
            
            const timer = setInterval(() => {
                current += increment;
                stat.textContent = Math.floor(current);
                
                if (current >= target) {
                    stat.textContent = target;
                    clearInterval(timer);
                }
            }, 16);
        });
        
        counted = true;
    }

    // Iniciar contador quando a seção estiver visível
    const aboutSection = document.querySelector('.about-section');
    if (aboutSection) {
        window.addEventListener('scroll', function() {
            const position = aboutSection.getBoundingClientRect();
            if (position.top < window.innerHeight && position.bottom >= 0) {
                startCounting();
            }
        });
    }

    // Botão voltar ao topo
    const backToTopBtn = document.querySelector('.back-to-top');
    if (backToTopBtn) {
        window.addEventListener('scroll', function() {
            if (window.scrollY > 300) {
                backToTopBtn.classList.add('show');
            } else {
                backToTopBtn.classList.remove('show');
            }
        });
        
        backToTopBtn.addEventListener('click', function(e) {
            e.preventDefault();
            window.scrollTo({
                top: 0,
                behavior: 'smooth'
            });
        });
    }

    // Integração com Typebot
    const typebotButton = document.getElementById('typebotButton');
    const typebotIframe = document.getElementById('typebotIframe');
    
    if (typebotButton && typebotIframe) {
        let typebotOpen = false;
        
        typebotButton.addEventListener('click', function(e) {
            e.preventDefault();
            
            if (!typebotOpen) {
                // Abrir o Typebot
                typebotIframe.src = "https://seu-typebot-url-aqui.com"; // Substitua pela URL do seu Typebot
                typebotIframe.classList.add('show');
                typebotOpen = true;
                typebotButton.innerHTML = '<i class="fas fa-times"></i>';
            } else {
                // Fechar o Typebot
                typebotIframe.classList.remove('show');
                setTimeout(() => {
                    typebotIframe.src = "about:blank";
                }, 300);
                typebotOpen = false;
                typebotButton.innerHTML = '<i class="fas fa-comments"></i>';
            }
        });
    }

    // Navegação suave para links internos
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function(e) {
            e.preventDefault();
            
            const target = document.querySelector(this.getAttribute('href'));
            if (target) {
                window.scrollTo({
                    top: target.offsetTop - 80,
                    behavior: 'smooth'
                });
                
                // Fechar menu mobile se estiver aberto
                if (mainNav.classList.contains('show')) {
                    mainNav.classList.remove('show');
                }
            }
        });
    });

    // Formulário de contato
    const contactForm = document.getElementById('contactForm');
    if (contactForm) {
        contactForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            // Aqui você pode adicionar a lógica para enviar o formulário via AJAX
            // Por enquanto, apenas simulamos uma submissão bem-sucedida
            
            const submitBtn = contactForm.querySelector('button[type="submit"]');
            const originalText = submitBtn.textContent;
            
            submitBtn.disabled = true;
            submitBtn.textContent = 'Enviando...';
            
            setTimeout(() => {
                alert('Mensagem enviada com sucesso! Entraremos em contato em breve.');
                contactForm.reset();
                submitBtn.disabled = false;
                submitBtn.textContent = originalText;
            }, 1500);
        });
    }
});
